

===== Thanks You For Purchasing =====


Feauture Of The Font:

- OTF And TTF

- Web Font

- Open Type Features Fonts

- PUA Encode

- Unique style fonts

- Easy customize


if you buy this font not from Maknastudio this ILLEGAL


Follow our official website :

- https://www.instagram.com/makna.std
- https://www.maknastudio.com

be Pleasure recommended my font

Thank you,

+++++++++++++++++++++++++++++++++++++++++++

How to instal fonts:

- Double click at the font files or Click Install fonts
- Adobe Illustrator CC or CS, Adobe Indesign and Coreldraw X ideal for edit the font
- Ready to use for Awesome Work

Tutorial Font:
Tutorial Open Type In Word:
https://www.youtube.com/watch?v=wnZViHZzOIE

Tutorial Open Type In Adobe Illustrator:
https://www.youtube.com/watch?v=pfDzGpv50dQ
https://www.youtube.com/watch?v=-ZM-1-_L73w
